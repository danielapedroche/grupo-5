﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WabiSabiWeb
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Alergenos(object sender, EventArgs e)
        {

        }
        protected void Carrito(object sender, EventArgs e)
        {

        }
        protected void Menu(object sender, EventArgs e)
        {

        }
        protected void Oferta(object sender, EventArgs e)
        {

        }
        protected void Orden(object sender, EventArgs e)
        {

        }
        protected void Pedido(object sender, EventArgs e)
        {

        }
        protected void Producto(object sender, EventArgs e)
        {

        }
        protected void Reseña(object sender, EventArgs e)
        {

        }
        protected void Suscripcion(object sender, EventArgs e)
        {

        }
        protected void Usuario(object sender, EventArgs e)
        {

        }
    }
}