﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WabiSabiWeb
{
    public partial class Producto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Leer_Click(object sender, EventArgs e)
        {

        }
        protected void Actualizar_Click(object sender, EventArgs e)
        {

        }
        protected void Crear_Click(object sender, EventArgs e)
        {

        }
        protected void Borrar_Click(object sender, EventArgs e)
        {

        }
    }
}